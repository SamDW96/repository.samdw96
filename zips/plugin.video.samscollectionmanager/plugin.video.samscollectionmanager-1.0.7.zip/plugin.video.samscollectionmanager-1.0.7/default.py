import os
import sys
import glob
import json
import shutil
import re

import xbmcaddon
import xbmcvfs
import xbmcgui
import xbmcplugin

from urllib.parse import parse_qs, urlparse, urlencode
from urllib.request import urlopen, Request
from urllib.error import URLError

# ─── Constants & Paths ─────────────────────────────────────────────
ADDON       = xbmcaddon.Addon()
HANDLE      = int(sys.argv[1])
SELF_BASE   = sys.argv[0]
HELPER_BASE = "plugin://plugin.video.themoviedb.helper/"

PROFILE     = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
COL_DIR     = os.path.join(PROFILE, 'collections')
CACHE_DIR   = os.path.join(PROFILE, 'cache')
CACHE_FILE  = os.path.join(CACHE_DIR, 'collections_cache.json')
MDBLIST_CACHE_FILE = os.path.join(CACHE_DIR, 'mdblist_index.json')
DEFAULTS    = os.path.join(os.path.dirname(__file__), 'resources', 'defaults')


# ─── Step 1: Prepare profile dirs & copy defaults ─────────────────
def prepare_profile():
    for d in (COL_DIR, CACHE_DIR):
        if not os.path.isdir(d):
            os.makedirs(d)
    for src in glob.glob(os.path.join(DEFAULTS, '*.json')):
        dst = os.path.join(COL_DIR, os.path.basename(src))
        if not os.path.exists(dst):
            shutil.copy(src, dst)


# ─── MDBlist Helper Functions ──────────────────────────────────────
def get_mdblist_apikey():
    """Try to get MDBlist API key from TMDbHelper settings."""
    try:
        tmdb_addon = xbmcaddon.Addon('plugin.video.themoviedb.helper')
        apikey = tmdb_addon.getSetting('mdblist_apikey')
        return apikey if apikey else None
    except (RuntimeError, Exception):
        # TMDbHelper addon may not be installed or setting doesn't exist
        return None


def load_mdblist_cache():
    """Load the MDBlist ID cache."""
    if os.path.exists(MDBLIST_CACHE_FILE):
        try:
            with open(MDBLIST_CACHE_FILE, 'r') as f:
                return json.load(f)
        except (IOError, json.JSONDecodeError):
            # Cache file may be corrupted or unreadable
            pass
    return {}


def save_mdblist_cache(cache):
    """Save the MDBlist ID cache."""
    try:
        with open(MDBLIST_CACHE_FILE, 'w') as f:
            json.dump(cache, f, indent=2)
    except (IOError, OSError):
        # Unable to write cache file - may not be critical
        pass


def parse_mdblist_url(url):
    """
    Parse an MDBlist URL and return the list_id.
    Supports two formats:
    1. Numeric: https://mdblist.com/?list=12345
    2. Pretty: https://mdblist.com/lists/username/list-slug
    
    Returns: (list_id, username, list_slug) or (None, None, None)
    """
    if not url:
        return None, None, None
    
    parsed = urlparse(url)
    
    # Check for numeric format: ?list=ID
    if parsed.query:
        params = parse_qs(parsed.query)
        if 'list' in params:
            list_id = params['list'][0]
            return list_id, None, None
    
    # Check for pretty format: /lists/username/list-slug
    path_parts = parsed.path.strip('/').split('/')
    if len(path_parts) >= 3 and path_parts[0] == 'lists':
        username = path_parts[1]
        list_slug = path_parts[2]
        return None, username, list_slug
    
    return None, None, None


def resolve_mdblist_id(username, list_slug, apikey):
    """
    Resolve a username/list-slug to a numeric list_id using MDBlist API.
    Requires an API key as per MDBlist API documentation.
    """
    if not username or not list_slug or not apikey:
        return None
    
    # Build API URL with apikey as query parameter (required by MDBlist API)
    api_url = f"https://api.mdblist.com/lists/{username}/{list_slug}?apikey={apikey}"
    
    try:
        headers = {'User-Agent': 'Kodi/SamsCollectionManager'}
        request = Request(api_url, headers=headers)
        response = urlopen(request, timeout=10)
        data = json.loads(response.read().decode('utf-8'))
        
        # The API returns an object with an 'id' field
        if 'id' in data:
            return str(data['id'])
    except (URLError, json.JSONDecodeError, KeyError):
        pass
    
    return None


def get_mdblist_list_id(url, cache_key):
    """
    Get the numeric list_id for an MDBlist URL.
    Uses cache to avoid unnecessary API calls.
    
    Args:
        url: The MDBlist URL
        cache_key: A unique key for this collection file (filename + mtime)
    
    Returns:
        The numeric list_id or None
    
    Note:
        For pretty URLs (username/slug format), an MDBlist API key is required.
        Configure it in TMDbHelper settings under 'mdblist_apikey'.
    """
    list_id, username, list_slug = parse_mdblist_url(url)
    
    # If already numeric, return it
    if list_id:
        return list_id
    
    # If pretty format, check cache or resolve
    if username and list_slug:
        cache = load_mdblist_cache()
        
        # Check if we have a cached result for this cache_key
        if cache_key in cache:
            cached_entry = cache[cache_key]
            if cached_entry.get('username') == username and cached_entry.get('list_slug') == list_slug:
                return cached_entry.get('list_id')
        
        # Not in cache, resolve it - requires API key
        apikey = get_mdblist_apikey()
        if not apikey:
            # Cannot resolve without API key
            return None
        
        list_id = resolve_mdblist_id(username, list_slug, apikey)
        
        if list_id:
            # Cache the result
            cache[cache_key] = {
                'username': username,
                'list_slug': list_slug,
                'list_id': list_id
            }
            save_mdblist_cache(cache)
            return list_id
    
    return None


# ─── Step 2: Load, prune & cache all collections ───────────────────
def load_all_collections():
    # 1) load existing cache or start fresh
    if os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, 'r') as f:
            cache = json.load(f)
    else:
        cache = {}

    # 2) determine which JSON files actually exist on disk
    existing = {os.path.basename(p) for p in glob.glob(os.path.join(COL_DIR, '*.json'))}

    # 3) remove stale cache entries for deleted files
    for fname in list(cache):
        if fname not in existing:
            del cache[fname]

    # 4) scan disk and add/update changed files
    for path in glob.glob(os.path.join(COL_DIR, '*.json')):
        fname = os.path.basename(path)
        mtime = int(os.path.getmtime(path))
        if fname not in cache or cache[fname]['mtime'] != mtime:
            with open(path, 'r') as f:
                data = json.load(f)
            
            # Resolve MDBlist URLs for any items that have mdblist_url
            cache_key_prefix = f"{fname}_{mtime}"
            for idx, item in enumerate(data.get('list', [])):
                if item.get('mdblist_url'):
                    cache_key = f"{cache_key_prefix}_item{idx}"
                    list_id = get_mdblist_list_id(item['mdblist_url'], cache_key)
                    if list_id:
                        # Store the resolved list_id in the item
                        item['_mdblist_id'] = list_id
            
            cache[fname] = {'mtime': mtime, 'data': data}

    # 5) write back the pruned & updated cache
    with open(CACHE_FILE, 'w') as f:
        json.dump(cache, f, indent=2)

    return cache


# ─── Step 3: List all collections as folders ───────────────────────
def list_collections(cache):
    xbmcplugin.setContent(HANDLE, 'files')
    for fname, entry in cache.items():
        meta = entry['data']
        name = meta.get('name', fname)
        art  = {}
        if meta.get('icon'):      art['thumb']     = meta['icon']
        if meta.get('icon'):      art['icon']      = meta['icon']
        if meta.get('fanart'):    art['fanart']    = meta['fanart']
        if meta.get('clearlogo'): art['clearlogo'] = meta['clearlogo']

        li = xbmcgui.ListItem(label=name)
        li.setArt(art)

        # show the top-level description in the info panel
        desc = meta.get('description')
        if desc:
            li.setInfo('video', {'plot': desc})

        url = f"{SELF_BASE}?collection={fname}"
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=url,
            listitem=li,
            isFolder=True
        )
    xbmcplugin.endOfDirectory(HANDLE)


# ─── URL builder helper ────────────────────────────────────────────
def build_item_url(collection_meta, item):
    # 1) full-path override?
    if item.get('path'):
        return item['path']

    # 2) Check for MDBlist URL first
    if item.get('mdblist_url'):
        # Get the resolved list_id (should be cached in item from load_all_collections)
        list_id = item.get('_mdblist_id')
        
        if list_id:
            # Build MDBlist URL for TMDbHelper
            plugin_cat = item.get('plugin_category',
                          item.get('title',
                          collection_meta.get('name','')))
            
            # Generate list_name from title (URL-safe: lowercase, alphanumeric with hyphens)
            title = item.get('title', 'mdblist')
            list_name = re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-') or 'mdblist'
            
            params = {
                'info': 'mdblist_userlist',
                'list_name': list_name,
                'list_id': list_id,
                'plugin_category': plugin_cat,
            }
            
            # tmdb_type (global or per-item)
            tmdb = item.get('tmdb_type', collection_meta.get('tmdb_type', None))
            if tmdb:
                params['tmdb_type'] = tmdb
            
            # exclude_unreleased?
            exclude = item.get('exclude_unreleased',
                      collection_meta.get('exclude_unreleased', False))
            if exclude:
                params.update({
                  'exclude_key': 'premiered',
                  'exclude_value': '$DAYS[0]',
                  'exclude_operator': 'gt'
                })
            
            # sorting?
            if item.get('sort_by'):
                params['sort_by'] = item['sort_by']
                params['sort_how'] = item.get('sort_how','desc')
            
            return HELPER_BASE + '?' + urlencode(params)

    # 3) parse trakt_url into user_slug & list_slug
    user_slug = list_slug = ''
    if item.get('trakt_url'):
        p = urlparse(item['trakt_url'])
        parts = p.path.strip('/').split('/')
        if 'users' in parts and 'lists' in parts:
            user_idx = parts.index('users') + 1
            list_idx = parts.index('lists') + 1
            user_slug = parts[user_idx]
            list_slug = parts[list_idx]

    # 4) assemble base params (use item title or override for plugin_category)
    plugin_cat = item.get('plugin_category',
                  item.get('title',
                  collection_meta.get('name','')))
    params = {
        'info': 'trakt_userlist',
        'user_slug': user_slug,
        'list_slug': list_slug,
        'plugin_category': plugin_cat,
        'extended': 'full',
    }

    # 5) tmdb_type (global or per-item)
    tmdb = item.get('tmdb_type', collection_meta.get('tmdb_type', None))
    if tmdb:
        params['tmdb_type'] = tmdb

    # 6) exclude_unreleased?
    exclude = item.get('exclude_unreleased',
              collection_meta.get('exclude_unreleased', False))
    if exclude:
        params.update({
          'exclude_key': 'premiered',
          'exclude_value': '$DAYS[0]',
          'exclude_operator': 'gt'
        })

    # 7) sorting?
    if item.get('sort_by'):
        params['sort_by'] = item['sort_by']
        params['sort_how'] = item.get('sort_how','desc')

    # 8) return TMDb Helper URL
    return HELPER_BASE + '?' + urlencode(params)


# ─── Step 4: List items inside one collection ──────────────────────
def list_items(cache, collection):
    entry = cache.get(collection)
    if not entry:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    data = entry['data']
    xbmcplugin.setContent(HANDLE, 'movies')
    if data.get('fanart'):
        xbmcplugin.setPluginFanart(HANDLE, image=data['fanart'])
    xbmcplugin.setPluginCategory(HANDLE, data.get('name', collection))

    for item in data.get('list', []):
        name = item.get('title') or item.get('name','No Title')
        li   = xbmcgui.ListItem(label=name)

        art = {}
        if item.get('icon'):
            art['thumb'] = item['icon']
            art['icon']  = item['icon']
        if item.get('fanart'):
            art['fanart'] = item['fanart']
        if item.get('clearlogo'):
            art['clearlogo'] = item['clearlogo']
        li.setArt(art)

        plot = item.get('plot') or item.get('description','')
        if plot:
            li.setInfo('video', {'plot': plot})

        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=build_item_url(data, item),
            listitem=li,
            isFolder=True
        )
    xbmcplugin.endOfDirectory(HANDLE)


# ─── Step 5: Router logic ──────────────────────────────────────────
def router():
    prepare_profile()
    cache = load_all_collections()
    params = parse_qs(urlparse(sys.argv[2]).query)
    if 'collection' in params:
        list_items(cache, params['collection'][0])
    else:
        list_collections(cache)


if __name__ == '__main__':
    router()
