# Sam's Collection Manager

**Version:** 1.0.6  
**Author:** Sam De Waegenaere  
**License:** GPL-2.0-or-later

## Overview

**Sam's Collection Manager** is a Kodi video addon designed to organize and manage TMDbHelper collections via local JSON configuration files. It supports both **Trakt** and **MDBlist** as list sources.

## Features

* **JSON Configuration:** Define your menus and items entirely in JSON.
* **Auto-Caching:** The addon caches your collections to ensure fast loading times and automatically updates when JSON files are modified.
* **TMDbHelper Integration:** Automatically builds complex plugin URLs for TMDbHelper, including sorting, filtering, and type selection.
* **Custom Artwork:** Supports custom icons, fanart, and clearlogos for both collections and individual items.
* **Content Filtering:** Global or per-item options to exclude unreleased content (e.g., movies that haven't premiered).
* **MDBlist Support:** Use MDBlist URLs in addition to Trakt URLs. Supports both numeric and pretty URL formats.

## Requirements

* **Kodi 19+ (Matrix)**
* **TMDbHelper** (`plugin.video.themoviedb.helper`) v6.9.11 or higher.

## Installation

### From ZIP File

1. **Download or Create ZIP:**
   - Download a release ZIP from GitHub, OR
   - Clone this repository and create a ZIP file containing all files (addon.xml, default.py, resources/, etc.)
   
2. **Install in Kodi:**
   - In Kodi, go to **Settings → Add-ons → Install from zip file**
   - Select the ZIP file
   - Wait for the "Add-on installed" notification

**Note:** This is a manual installation method without automatic updates. To update, repeat the process with a newer version.

## Configuration

The addon looks for JSON files in:
```
special://profile/addon_data/plugin.video.samscollectionmanager/collections/
```

### JSON Structure

Each JSON file represents a top-level "Collection" folder in Kodi.

```json
{
  "name": "My Custom Collection",
  "description": "A collection of my favorite lists.",
  "exclude_unreleased": true,
  "tmdb_type": "movie",
  "list": [
    {
      "title": "Trending Movies",
      "trakt_url": "https://trakt.tv/users/username/lists/trending",
      "icon": "/path/to/icon.jpg",
      "sort_by": "popularity",
      "sort_how": "desc"
    }
  ]
}
```

### MDBlist Support

You can use **MDBlist** URLs in addition to Trakt URLs. The addon supports both URL formats:

#### Numeric Format
```json
{
  "title": "Top IMDb Movies",
  "mdblist_url": "https://mdblist.com/?list=12345"
}
```

#### Pretty Format (Username/Slug)
```json
{
  "title": "My Watchlist",
  "mdblist_url": "https://mdblist.com/lists/username/my-watchlist"
}
```

The addon will automatically resolve pretty URLs to numeric list IDs using the MDBlist API. The resolved IDs are cached in `cache/mdblist_index.json` to minimize API calls.

**Important:** Pretty URLs (username/slug format) **require** an MDBlist API key. You must configure your MDBlist API key in **TMDbHelper settings** (`mdblist_apikey`). Numeric format URLs work without an API key.

### Field Reference

#### Collection Level
- `name`: Display name for the collection
- `description`: Description shown in the info panel
- `exclude_unreleased`: Global filter for unreleased content (boolean)
- `tmdb_type`: Default media type: `"movie"` or `"tv"`
- `icon`, `fanart`, `clearlogo`: Custom artwork URLs
- `list`: Array of list items

#### Item Level
- `title`: Display name (required)
- `trakt_url`: Trakt list URL
- `mdblist_url`: MDBlist URL (alternative to trakt_url)
- `path`: Full plugin URL override (bypasses all URL building)
- `plugin_category`: Custom category name
- `tmdb_type`: Override media type for this item
- `exclude_unreleased`: Override unreleased filter for this item
- `sort_by`: Sort field (e.g., `"popularity"`, `"released"`)
- `sort_how`: Sort direction: `"asc"` or `"desc"`
- `icon`, `fanart`, `clearlogo`: Custom artwork
- `plot` / `description`: Item description

### Example: MDBlist Configuration

```json
{
  "name": "MDBlist Collections",
  "description": "Popular lists from MDBlist.com",
  "tmdb_type": "movie",
  "list": [
    {
      "title": "Top 250 Movies",
      "mdblist_url": "https://mdblist.com/lists/mdblist/top-250-movies",
      "icon": "https://example.com/top250.jpg"
    },
    {
      "title": "Oscar Winners",
      "mdblist_url": "https://mdblist.com/?list=67890",
      "sort_by": "year",
      "sort_how": "desc"
    }
  ]
}
```

## How It Works

1. **Profile Setup:** On first run, the addon creates necessary directories and copies default JSON examples
2. **Collection Loading:** Scans the collections folder for JSON files
3. **Caching:** Caches file contents based on modification time for fast loading
4. **MDBlist Resolution:** When a collection file is added or modified, pretty MDBlist URLs are resolved to numeric IDs and cached
5. **URL Building:** Constructs TMDbHelper plugin URLs based on your configuration
6. **Display:** Shows collections as browsable folders with custom artwork

## Troubleshooting

### MDBlist URLs not working
- Verify the URL format is correct (numeric or username/slug)
- **For pretty URLs (username/slug):** Ensure you have configured an MDBlist API key in TMDbHelper settings - this is required by the MDBlist API
- Check your internet connection
- Check the cache file: `cache/mdblist_index.json`

### Collections not updating
- The addon checks file modification times
- Edit and save the JSON file to trigger a refresh
- Or delete `cache/collections_cache.json` to force a full reload

## License

GPL-2.0-or-later
