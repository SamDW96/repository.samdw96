# Sam's Collection Manager

A Kodi video addon for organizing TMDbHelper collections using local JSON configuration files. Supports **Trakt** and **MDBlist** list sources, with automatic caching, custom artwork, and content filtering options.

## Requirements

* Kodi 19+ (Matrix)
* TMDbHelper (`plugin.video.themoviedb.helper`) v6.9.11 or higher

## Installation

Download a release ZIP from GitHub (or clone the repo and create a ZIP). In Kodi, go to **Settings → Add-ons → Install from zip file** and select the ZIP. Alternatively, install the repo at https://github.com/SamDW96/repository.samdw96

## Configuration

Place JSON files in `special://profile/addon_data/plugin.video.samscollectionmanager/collections/`. Each file represents a top-level collection folder in Kodi.

### JSON Example

```json
{
  "name": "My Collections",
  "description": "Custom movie and TV collections",
  "exclude_unreleased": true,
  "tmdb_type": "movie",
  "icon": "/path/to/icon.jpg",
  "list": [
    {
      "title": "Trending Movies",
      "trakt_url": "https://trakt.tv/users/username/lists/trending",
      "icon": "/path/to/trending.jpg",
      "sort_by": "popularity",
      "sort_how": "desc"
    },
    {
      "title": "Top IMDb Movies",
      "mdblist_url": "https://mdblist.com/?list=12345",
      "sort_by": "year",
      "sort_how": "desc"
    }
  ]
}
```

### Getting MDBlist List IDs

To use MDBlist URLs, you need the numeric list ID:

1. Navigate to the list on MDBlist (e.g., `https://mdblist.com/lists/garycrawfordgc/latest-tv-shows`)
2. Click **Actions** → **Create your Show/Movie Filter**
3. Copy the URL from the browser address bar (e.g., `https://mdblist.com/?list=2194`)
4. Use this URL in your JSON configuration

### Field Reference

#### Collection Level
- `name`: Display name for the collection
- `description`: Description shown in the info panel
- `exclude_unreleased`: Global filter for unreleased content (boolean)
- `tmdb_type`: Default media type: `"movie"` or `"tv"`
- `icon`, `fanart`, `clearlogo`: Custom artwork URLs
- `list`: Array of list items

#### Item Level
- `title`: Display name (required)
- `trakt_url`: Trakt list URL
- `mdblist_url`: MDBlist URL (alternative to trakt_url)
- `path`: Full plugin URL override (bypasses all URL building)
- `plugin_category`: Custom category name
- `tmdb_type`: Override media type for this item
- `exclude_unreleased`: Override unreleased filter for this item
- `sort_by`: Sort field (e.g., `"popularity"`, `"released"`)
- `sort_how`: Sort direction: `"asc"` or `"desc"`
- `icon`, `fanart`, `clearlogo`: Custom artwork
- `plot` / `description`: Item description

## How It Works

On first run, the addon creates necessary directories and copies default JSON examples. It scans the collections folder for JSON files, caches them based on modification time, parses MDBlist/Trakt URLs, builds TMDbHelper plugin URLs, and displays collections as browsable folders with custom artwork.

## Troubleshooting

**MDBlist URLs not working:** Verify the URL format is `https://mdblist.com/?list=12345` with the numeric list ID (see "Getting MDBlist List IDs").

**Collections not updating:** Edit and save the JSON file to trigger a refresh, or delete `cache/collections_cache.json` to force a full reload.

## License

GPL-2.0-or-later
