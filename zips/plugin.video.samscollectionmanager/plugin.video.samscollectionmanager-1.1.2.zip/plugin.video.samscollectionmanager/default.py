import os
import sys
import glob
import json
import shutil
import re

import xbmcaddon
import xbmcvfs
import xbmcgui
import xbmcplugin

from urllib.parse import parse_qs, urlparse, urlencode

# ─── Constants & Paths ─────────────────────────────────────────────
ADDON       = xbmcaddon.Addon()
HANDLE      = int(sys.argv[1])
SELF_BASE   = sys.argv[0]
HELPER_BASE = "plugin://plugin.video.themoviedb.helper/"

PROFILE     = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
COL_DIR     = os.path.join(PROFILE, 'collections')
CACHE_DIR   = os.path.join(PROFILE, 'cache')
CACHE_FILE  = os.path.join(CACHE_DIR, 'collections_cache.json')
DEFAULTS    = os.path.join(os.path.dirname(__file__), 'resources', 'defaults')


# ─── Step 1: Prepare profile dirs & copy defaults ─────────────────
def prepare_profile():
    for d in (COL_DIR, CACHE_DIR):
        if not os.path.isdir(d):
            os.makedirs(d)
    for src in glob.glob(os.path.join(DEFAULTS, '*.json')):
        dst = os.path.join(COL_DIR, os.path.basename(src))
        if not os.path.exists(dst):
            shutil.copy(src, dst)


# ─── MDBlist Helper Functions ──────────────────────────────────────
def parse_mdblist_url(url):
    """
    Parse an MDBlist URL and return the list_id.
    Only supports numeric format: https://mdblist.com/?list=12345
    
    Returns: str (the list_id) or None
    """
    if not url:
        return None
    
    parsed = urlparse(url)
    
    # Check for numeric format: ?list=ID
    if parsed.query:
        params = parse_qs(parsed.query)
        if 'list' in params:
            return params['list'][0]
    
    return None


# ─── URL builder helper ────────────────────────────────────────────
def build_helper_url(collection_meta, item):
    # 1) full-path override?
    if item.get('path'):
        return item['path']

    # 2) Check for MDBlist URL first
    if item.get('mdblist_url'):
        # Get the resolved list_id (should be cached in item from load_all_collections)
        list_id = item.get('_mdblist_id')
        
        if list_id:
            # Build MDBlist URL for TMDbHelper
            plugin_cat = item.get('plugin_category',
                          item.get('title',
                          collection_meta.get('name','')))
            
            # Generate list_name from title (URL-safe: lowercase, alphanumeric with hyphens)
            title = item.get('title', 'mdblist')
            list_name = re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-') or 'mdblist'
            
            params = {
                'info': 'mdblist_userlist',
                'list_name': list_name,
                'list_id': list_id,
                'plugin_category': plugin_cat,
            }
            
            # tmdb_type (global or per-item)
            tmdb = item.get('tmdb_type', collection_meta.get('tmdb_type', None))
            if tmdb:
                params['tmdb_type'] = tmdb
            
            # exclude_unreleased?
            exclude = item.get('exclude_unreleased',
                      collection_meta.get('exclude_unreleased', False))
            if exclude:
                params.update({
                  'exclude_key': 'premiered',
                  'exclude_value': '$DAYS[0]',
                  'exclude_operator': 'gt'
                })
            
            # sorting?
            if item.get('sort_by'):
                params['sort_by'] = item['sort_by']
                params['sort_how'] = item.get('sort_how','desc')
            
            return HELPER_BASE + '?' + urlencode(params)

    # 3) parse trakt_url into user_slug & list_slug
    user_slug = list_slug = ''
    if item.get('trakt_url'):
        p = urlparse(item['trakt_url'])
        parts = p.path.strip('/').split('/')
        if 'users' in parts and 'lists' in parts:
            user_idx = parts.index('users') + 1
            list_idx = parts.index('lists') + 1
            user_slug = parts[user_idx]
            list_slug = parts[list_idx]

    # 4) assemble base params (use item title or override for plugin_category)
    plugin_cat = item.get('plugin_category',
                  item.get('title',
                  collection_meta.get('name','')))
    params = {
        'info': 'trakt_userlist',
        'user_slug': user_slug,
        'list_slug': list_slug,
        'plugin_category': plugin_cat,
        'extended': 'full',
    }

    # 5) tmdb_type (global or per-item)
    tmdb = item.get('tmdb_type', collection_meta.get('tmdb_type', None))
    if tmdb:
        params['tmdb_type'] = tmdb

    # 6) exclude_unreleased?
    exclude = item.get('exclude_unreleased',
              collection_meta.get('exclude_unreleased', False))
    if exclude:
        params.update({
          'exclude_key': 'premiered',
          'exclude_value': '$DAYS[0]',
          'exclude_operator': 'gt'
        })

    # 7) sorting?
    if item.get('sort_by'):
        params['sort_by'] = item['sort_by']
        params['sort_how'] = item.get('sort_how','desc')

    # 8) return TMDb Helper URL
    return HELPER_BASE + '?' + urlencode(params)


# ─── Step 2: Load, prune & cache all collections ───────────────────
def load_all_collections():
    # 1) load existing cache or start fresh
    if os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, 'r') as f:
            cache = json.load(f)
    else:
        cache = {}

    # 2) determine which JSON files actually exist on disk
    existing = {os.path.basename(p) for p in glob.glob(os.path.join(COL_DIR, '*.json'))}

    # 3) remove stale cache entries for deleted files
    for fname in list(cache):
        if fname not in existing:
            del cache[fname]

    # 4) scan disk and add/update changed files
    for path in glob.glob(os.path.join(COL_DIR, '*.json')):
        fname = os.path.basename(path)
        mtime = int(os.path.getmtime(path))
        if fname not in cache or cache[fname]['mtime'] != mtime:
            with open(path, 'r') as f:
                data = json.load(f)
            
            # Extract MDBlist IDs and pre-calculate final URLs for all items
            for item in data.get('list', []):
                if item.get('mdblist_url'):
                    list_id = parse_mdblist_url(item['mdblist_url'])
                    if list_id:
                        # Store the extracted list_id in the item
                        item['_mdblist_id'] = list_id
                
                # Pre-calculate and store the final URL
                item['_final_url'] = build_helper_url(data, item)
            
            cache[fname] = {'mtime': mtime, 'data': data}

    # 5) write back the pruned & updated cache
    with open(CACHE_FILE, 'w') as f:
        json.dump(cache, f, indent=2)

    return cache


# ─── Step 3: List all collections as folders ───────────────────────
def list_collections(cache):
    xbmcplugin.setContent(HANDLE, 'files')
    for fname, entry in cache.items():
        meta = entry['data']
        name = meta.get('name', fname)
        art  = {}
        if meta.get('icon'):      art['thumb']     = meta['icon']
        if meta.get('icon'):      art['icon']      = meta['icon']
        if meta.get('fanart'):    art['fanart']    = meta['fanart']
        if meta.get('clearlogo'): art['clearlogo'] = meta['clearlogo']

        li = xbmcgui.ListItem(label=name)
        li.setArt(art)

        # show the top-level description in the info panel
        desc = meta.get('description')
        if desc:
            li.setInfo('video', {'plot': desc})

        url = f"{SELF_BASE}?collection={fname}"
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=url,
            listitem=li,
            isFolder=True
        )
    xbmcplugin.endOfDirectory(HANDLE)


# ─── Step 4: List items inside one collection ──────────────────────
def list_items(cache, collection):
    entry = cache.get(collection)
    if not entry:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    data = entry['data']
    xbmcplugin.setContent(HANDLE, 'movies')
    if data.get('fanart'):
        xbmcplugin.setPluginFanart(HANDLE, image=data['fanart'])
    xbmcplugin.setPluginCategory(HANDLE, data.get('name', collection))

    for item in data.get('list', []):
        name = item.get('title') or item.get('name','No Title')
        li   = xbmcgui.ListItem(label=name)

        art = {}
        if item.get('icon'):
            art['thumb'] = item['icon']
            art['icon']  = item['icon']
        if item.get('fanart'):
            art['fanart'] = item['fanart']
        if item.get('clearlogo'):
            art['clearlogo'] = item['clearlogo']
        li.setArt(art)

        plot = item.get('plot') or item.get('description','')
        if plot:
            li.setInfo('video', {'plot': plot})

        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=item.get('_final_url', ''),
            listitem=li,
            isFolder=True
        )
    xbmcplugin.endOfDirectory(HANDLE)


# ─── Step 5: Router logic ──────────────────────────────────────────
def router():
    prepare_profile()
    cache = load_all_collections()
    params = parse_qs(urlparse(sys.argv[2]).query)
    if 'collection' in params:
        list_items(cache, params['collection'][0])
    else:
        list_collections(cache)


if __name__ == '__main__':
    router()
